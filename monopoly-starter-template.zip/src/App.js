
import React, { useState } from 'react';

export default function App() {
  const [player, setPlayer] = useState('');
  const [turn, setTurn] = useState(1);
  const [position, setPosition] = useState(0);

  const movePlayer = () => {
    setPosition((pos) => (pos + 1) % 20);
    setTurn((t) => t + 1);
  };

  return (
    <div style={{ padding: 20, fontFamily: 'Arial' }}>
      <h1>Monopoly Starter Game</h1>
      <input
        placeholder="Enter your player name"
        value={player}
        onChange={(e) => setPlayer(e.target.value)}
      />
      <p>Turn: {turn}</p>
      <p>Player: {player || 'No player yet'}</p>
      <p>Position: {position}</p>
      <button onClick={movePlayer} disabled={!player}>Move 1 space</button>
      <p>(Board and cards will be added later.)</p>
    </div>
  );
}
