# Monopoly Starter Template
Basic starter for Monopoly-style board game.